/*!
 * @name Sayqz 音乐聚合源
 * @description 支持网易云、QQ音乐、酷狗等多平台音乐搜索和播放
 * @version 1.0.2
 * @author Ceru
 */

'use strict';

// ==================== 配置区 ====================

const DEV_ENABLE = false;
const API_BASE_URL = 'https://music-dl.sayqz.com/api/';

// LX Music 平台代码 -> Sayqz API 平台代码映射
const PLATFORM_MAP = {
    'wy': 'netease',
    'tx': 'qq',
    'kg': 'kugou',
    'kw': 'kuwo',
    'mg': 'migu'
};

// 支持的音质
const MUSIC_QUALITY = {
    'wy': ['128k', '320k', 'flac'],
    'tx': ['128k', '320k', 'flac'],
    'kg': ['128k', '320k', 'flac'],
    'kw': ['128k', '320k', 'flac'],
    'mg': ['128k', '320k', 'flac']
};

const PLATFORM_NAMES = {
    'wy': '网易云音乐',
    'tx': 'QQ音乐',
    'kg': '酷狗音乐',
    'kw': '酷我音乐',
    'mg': '咪咕音乐'
};

// ==================== 工具函数 ====================

const log = (msg, ...args) => console.log(`[Sayqz]`, msg, ...args);
const error = (msg, ...args) => console.error(`[Sayqz]`, msg, ...args);

// 转换平台代码
const convertPlatform = (lxPlatform) => PLATFORM_MAP[lxPlatform] || lxPlatform;

// 构建 API URL
const buildApiUrl = (params) => {
    const queryString = Object.entries(params)
        .map(([key, value]) => `${key}=${encodeURIComponent(value)}`)
        .join('&');
    return `${API_BASE_URL}?${queryString}`;
};

// ==================== 主要功能 ====================

// HTTP 请求封装
const httpFetch = (url, options = {}) => {
    const { request } = globalThis.lx;
    return new Promise((resolve, reject) => {
        request(url, options, (err, response) => {
            if (err) return reject(err);
            resolve(response);
        });
    });
};

// 获取音乐播放链接（改进版）
const handleGetMusicUrl = async (source, musicInfo, quality) => {
    const apiSource = convertPlatform(source);
    const songId = musicInfo.songmid || musicInfo.id;
    
    if (!songId) {
        throw new Error('缺少歌曲 ID');
    }

    // 音质降级策略
    const qualityPriority = {
        'flac24bit': ['flac', '320k', '128k'],
        'flac': ['flac', '320k', '128k'],
        '320k': ['320k', '128k'],
        '128k': ['128k']
    };

    const qualitiesToTry = qualityPriority[quality] || ['320k', '128k'];
    
    log(`获取链接 - 平台: ${source}(${apiSource}), ID: ${songId}, 目标音质: ${quality}`);

    // 尝试不同音质
    for (const tryQuality of qualitiesToTry) {
        try {
            const url = buildApiUrl({
                source: apiSource,
                id: songId,
                type: 'url',
                br: tryQuality
            });

            log(`尝试音质: ${tryQuality}`);

            const response = await httpFetch(url, {
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Referer': 'https://music-dl.sayqz.com/',
                    'Accept': '*/*',
                    'Accept-Language': 'zh-CN,zh;q=0.9',
                    'Origin': 'https://music-dl.sayqz.com'
                },
                timeout: 10000
            });

            const contentType = response.headers['content-type'] || '';
            const isAudio = contentType.includes('audio') || 
                           contentType.includes('application/octet-stream') ||
                           contentType.includes('video/mp4');

            if (response.statusCode === 200 && isAudio) {
                log(`✅ 成功获取 ${tryQuality} 音质链接`);
                return url;
            } else if (response.statusCode === 200) {
                log(`⚠️ ${tryQuality} 返回非音频内容，尝试下一个音质`);
                continue;
            } else {
                log(`⚠️ ${tryQuality} 不可用 (状态码: ${response.statusCode})`);
                continue;
            }

        } catch (err) {
            log(`⚠️ ${tryQuality} 请求失败: ${err.message}`);
            continue;
        }
    }

    throw new Error(`所有音质都不可用 (尝试了: ${qualitiesToTry.join(', ')})`);
};

// 搜索音乐
const handleSearch = async (source, keyword, page = 1, limit = 30) => {
    const apiSource = convertPlatform(source);
    
    const url = buildApiUrl({
        source: apiSource,
        type: 'search',
        keyword: keyword,
        limit: limit,
        page: page
    });

    log(`搜索: ${keyword} (平台: ${source})`);

    const response = await httpFetch(url, {
        method: 'GET',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    });

    const { body } = response;

    if (!body || body.code !== 200) {
        throw new Error(body?.message || '搜索失败');
    }

    const results = body.data.results.map(song => ({
        singer: song.artist || '未知歌手',
        name: song.name,
        albumName: song.album || '',
        albumId: song.albumId || '',
        songmid: song.id,
        id: song.id,
        source: source,
        interval: song.duration ? Math.floor(song.duration / 1000) : null,
        img: song.pic || null
    }));

    log(`✅ 搜索成功: ${results.length} 首歌曲`);

    return {
        list: results,
        allPage: body.data.totalPages || 1,
        limit: limit,
        source: source
    };
};

// 获取歌词
const handleGetLyric = async (source, musicInfo) => {
    const apiSource = convertPlatform(source);
    const songId = musicInfo.songmid || musicInfo.id;
    
    if (!songId) {
        throw new Error('缺少歌曲 ID');
    }

    const url = buildApiUrl({
        source: apiSource,
        id: songId,
        type: 'lyric'
    });

    const response = await httpFetch(url, {
        method: 'GET',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    });

    const { body } = response;

    if (!body || body.code !== 200) {
        return { lyric: '', tlyric: '' };
    }

    return {
        lyric: body.data.lyric || '',
        tlyric: body.data.tlyric || ''
    };
};

// 获取歌曲图片
const handleGetPic = async (source, musicInfo) => {
    if (musicInfo.img) {
        return musicInfo.img;
    }

    const apiSource = convertPlatform(source);
    const songId = musicInfo.songmid || musicInfo.id;
    
    if (!songId) {
        return null;
    }

    const url = buildApiUrl({
        source: apiSource,
        id: songId,
        type: 'pic'
    });

    const response = await httpFetch(url, {
        method: 'GET',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
    });

    const { body } = response;

    if (body && body.code === 200 && body.data && body.data.pic) {
        return body.data.pic;
    }

    return null;
};

// ==================== 插件初始化 ====================

const initPlugin = () => {
    const { EVENT_NAMES, on, send } = globalThis.lx;

    // 构建音乐源配置
    const musicSources = {};
    Object.keys(MUSIC_QUALITY).forEach(source => {
        musicSources[source] = {
            name: PLATFORM_NAMES[source],
            type: 'music',
            actions: ['musicUrl', 'search', 'lyric', 'pic'],
            qualitys: MUSIC_QUALITY[source]
        };
    });

    // 注册事件监听器
    on(EVENT_NAMES.request, async ({ action, source, info }) => {
        try {
            log(`收到请求: action=${action}, source=${source}`);

            switch (action) {
                case 'musicUrl':
                    return await handleGetMusicUrl(source, info.musicInfo, info.quality);

                case 'search':
                    return await handleSearch(source, info.keyword, info.page, info.limit);

                case 'lyric':
                    return await handleGetLyric(source, info.musicInfo);

                case 'pic':
                    return await handleGetPic(source, info.musicInfo);

                default:
                    throw new Error(`不支持的操作: ${action}`);
            }
        } catch (err) {
            error(`❌ ${action} 失败:`, err.message);
            throw err;
        }
    });

    // 发送初始化完成事件
    send(EVENT_NAMES.inited, {
        status: true,
        openDevTools: DEV_ENABLE,
        sources: musicSources
    });

    log('✅ 插件初始化成功');
    log('支持的平台:', Object.keys(musicSources).join(', '));
};

// 启动插件
try {
    initPlugin();
} catch (err) {
    console.error('[Sayqz] ❌ 插件初始化失败:', err);
    throw err;
}
